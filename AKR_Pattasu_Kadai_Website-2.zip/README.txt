AKR PATTASU KADAI website
Open index.html in a browser to preview.
The site is an informational catalogue/contact page and does not contain an online purchase or payment checkout.
Shop: AKR PATTASU KADAI
Address: Kalugumalai Road, Vembakkottai
Phone: 9655722768 / 8825454060
Email: sivasankarm950@gmail.com
